from flask import Flask, render_template, request, redirect, session, Markup
# import random
# import datetime

app = Flask(__name__)
# static_url_path = "", static_folder = "static")
app.secret_key = 'ThisIsSecret'

@app.route('/')
def index():

    return render_template('index.html')


@app.route('/ninja/<color>')
@app.route('/ninja')
def route_ninja(color=None):
    return render_template("turtle.html", color=color)


@app.route('/process_money', methods=["POST"])
def process_gold():
    selectedBuilding = request.form["building"]
    if selectedBuilding == "Farm":
        gain = random.randrange(10,21);
        session['gold'] += gain
    elif selectedBuilding == "Cave":
        gain = random.randrange(5,11);
        session['gold'] += gain
    elif selectedBuilding == "House":
        gain = random.randrange(2,6);
        session['gold'] += gain
    elif selectedBuilding == "Casino":
        gain = random.randrange(-50,51);
        session['gold'] += gain
        if session['gold'] < 0:
            session['gold'] = 0

    if(gain > 0):
        session['log'].insert(0,[ session['gold'], ("Earned {} golds from the {}. ({})").format(gain, selectedBuilding, datetime.datetime.now().strftime("%A, %d. %B %Y %I:%M%p"))])
    elif(gain <= 0):
        session['log'].insert(0,[gain, ("Entered a casino and lost {} golds... Ouch...({})").format(gain, datetime.datetime.now().strftime("%A, %d. %B %Y %I:%M%p"))])

    return redirect('/')
app.run(debug=True) # run our server
# random.randrange(0, 101)
